import json
import numpy as np
import math  # 导入 math 库用于 pi

"""
功能：[1]将得到机器人基座位姿和工件的位姿，计算工件相对于机器人的相对位姿(坐标+四元数)，最后用于机器人脚本参数的输入
"""
# 尝试导入 scipy
try:
    from scipy.spatial.transform import Rotation
except ImportError:
    print("错误：未找到 scipy 库。")
    print("请先安装: pip install scipy numpy")
    exit()


# --- 移除：ikpy 相关的导入 ---


# -------------------------


# --- 移除：create_irb120_chain() 函数 ---
# (整个函数已删除)


def create_4x4_matrix(position, quaternion):
    """
    根据位置 (list) 和四元数 (list [x, y, z, w])
    创建一个 4x4 齐次变换矩阵。
    """
    try:
        # SciPy 的 from_quat 期望 [x, y, z, w]
        rot_matrix_3x3 = Rotation.from_quat(quaternion).as_matrix()
    except Exception as e:
        print(f"错误：无效的四元数 {quaternion}。{e}")
        return None

    # 创建 4x4 齐次矩阵
    matrix_4x4 = np.identity(4)
    matrix_4x4[0:3, 0:3] = rot_matrix_3x3
    matrix_4x4[0:3, 3] = position

    return matrix_4x4


def load_data(filename='scene_data.json'):
    """
    从 JSON 文件加载场景数据。
    并将在 [W, X, Y, Z] 格式的四元数转换回 [X, Y, Z, W]
    """
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            data = json.load(f)

        # --- ✅ 新增：从 [W, X, Y, Z] 格式读取 ---
        # 转换回 Scipy 期望的 [X, Y, Z, W] 格式
        if data:
            for item in data:
                if "Rotate" in item:
                    # 从 [W, X, Y, Z] 格式读取
                    quat_wxyz = item["Rotate"]
                    # 转换回 Scipy 期望的 [X, Y, Z, W] 格式
                    # w = quat_wxyz[0], x = quat_wxyz[1], y = quat_wxyz[2], z = quat_wxyz[3]
                    item["Rotate"] = [quat_wxyz[1], quat_wxyz[2], quat_wxyz[3], quat_wxyz[0]]
        # -----------------------------------

        return data
    except FileNotFoundError:
        print(f"错误：未找到 {filename}。")
        print("请先运行 client.py 并输入 'get' 来生成该文件。")
        return None
    except json.JSONDecodeError:
        print(f"错误：{filename} 文件中的 JSON 格式不正确。")
        return None


def calculate_poses():
    """
    主函数：加载数据，执行坐标变换，并计算逆向运动学。
    """
    # 0. 加载数据
    scene_data = load_data()
    if not scene_data:
        return

    # 1. 查找并提取机器人基座的数据
    robot_base_data = None
    workpieces_data = []

    for item in scene_data:
        # --- 使用英文键名 ---
        if item.get("Type") == "机器人":
            robot_base_data = item
        elif item.get("Type") == "工件":
            workpieces_data.append(item)

    if not robot_base_data:
        # --- 更新错误消息 ---
        print("错误：在 scene_data.json 中未找到 'Type' 为 '机器人' 的基座数据。")
        return

    # --- 移除：创建机器人运动学模型 ---
    # (robot_chain = create_irb120_chain() 已删除)
    # ---------------------------------

    # 2. 创建机器人基座的 4x4 变换矩阵 (T_world_to_base)
    # --- 使用英文键名 ---
    base_pos = robot_base_data["Location"]
    base_quat = robot_base_data["Rotate"]  # 此时已经是 [X, Y, Z, W] 格式
    T_world_to_base = create_4x4_matrix(base_pos, base_quat)

    if T_world_to_base is None:
        print("错误：机器人基座的四元数无效，计算中止。")
        return

    # 3. 计算从 "世界" 返回到 "基座" 的逆矩阵 (T_base_to_world)
    #    这是从基座坐标系看向世界坐标系的变换
    T_base_to_world = np.linalg.inv(T_world_to_base)

    print("-" * 40)
    print(f"机器人基座 '{robot_base_data.get('Name')}' 加载成功。")
    print(f"找到 {len(workpieces_data)} 个工件。")
    print("开始计算工件相对于基座的坐标：\n")

    # 4. 遍历所有工件，计算它们相对于基座的位姿
    for wp in workpieces_data:
        # --- 使用英文键名 ---
        wp_name = wp["Name"]
        wp_pos_world = wp["Location"]
        wp_quat_world = wp["Rotate"]  # 此时已经是 [X, Y, Z, W] 格式

        # 5. 创建工件的 4x4 变换矩阵 (T_world_to_workpiece)
        T_world_to_workpiece = create_4x4_matrix(wp_pos_world, wp_quat_world)

        if T_world_to_workpiece is None:
            print(f"跳过 {wp_name} (无效的四元数)")
            continue

        # 6. 【核心计算】
        #    T_base_to_workpiece = T_base_to_world * T_world_to_workpiece
        #    (矩阵乘法 @)
        T_base_to_workpiece = T_base_to_world @ T_world_to_workpiece

        # 7. 从最终的 4x4 矩阵中提取出机器人需要的位置和姿态
        #    (这是机器人控制器需要的目标位姿)
        final_pos_in_base = T_base_to_workpiece[0:3, 3]
        final_rot_matrix = T_base_to_workpiece[0:3, 0:3]
        final_rotation = Rotation.from_matrix(final_rot_matrix)
        final_euler_in_base_deg = final_rotation.as_euler('xyz', degrees=True)
        final_quat_in_base = final_rotation.as_quat()  # Scipy 返回 [x, y, z, w]

        # --- 移除：求解逆向运动学 (IK) ---
        # (整个 try...except IK 求解块已删除)

        # --- ✅ 新增：根据用户请求格式化输出字符串 ---

        # 格式化位置: [-0.1735f, 0.07f, ...]
        # 使用 'g' 格式自动处理小数位数并附加 'f'
        pos_str = f"[{', '.join([f'{v:g}f' for v in final_pos_in_base])}]"

        # 格式化欧拉角: [180, 0, 180]
        # 使用 ':.0f' 强制转为整数显示
        euler_str = f"[{', '.join([f'{v:.0f}' for v in final_euler_in_base_deg])}]"

        # 格式化四元数: [0, 0, 1, 0]
        # 重新排序 [x, y, z, w] -> [w, x, y, z]
        final_quat_wxyz = [final_quat_in_base[3], final_quat_in_base[0], final_quat_in_base[1], final_quat_in_base[2]]
        # 使用 ':.0f' 强制转为整数显示
        quat_str = f"[{', '.join([f'{v:.0f}' for v in final_quat_wxyz])}]"

        # 打印结果
        print(f"--- {wp_name} (相对于基座) ---")
        print(f"  位置 (X, Y, Z): {pos_str}")
        print(f"  欧拉角 (绕X, Y, Z旋转/度): {euler_str}")
        print(f"  (四元数 W, X, Y, Z): {quat_str}")
        print("\n")  # 保持原有的换行


if __name__ == "__main__":
    calculate_poses()