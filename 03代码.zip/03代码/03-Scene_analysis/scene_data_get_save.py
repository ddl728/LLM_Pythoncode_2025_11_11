import socket
import time
import json  # 导入 JSON 模块
import os  # 导入 OS 模块 (虽然在这个版本中不是必需的，但通常很有用)
"""
功能：[1]处理与服务器的持续通信。等待用户输入指令来决定何时发送数据。
     [2]数据包括工件坐标、四元数数据及尺寸；机器人基座的坐标及四元数数据
     [3]永久存储到"scene_data.json"中
     [4]JSON存储四元数数据顺序[W、X、Y、Z]
"""

def save_data_to_json(data_string, filename='scene_data.json'):
    """
    将接收到的字符串数据解析为 JSON，提取内部的工件数据，
    并将其永久存储到文件中。
    文件将被覆盖以反映最新的数据。

    :param data_string: 从服务器接收到的原始字符串数据
    :param filename: 要保存到的文件名
    """
    try:
        # 1. 解析外层 JSON 字符串 (e.g., {"type": 1, "data": {...}})
        outer_obj = json.loads(data_string)

        # 2. 检查 "data" 和 "P0" 键是否存在
        if 'data' in outer_obj and 'P0' in outer_obj['data']:
            # 3. 提取 "P0" 键的值，它本身是一个 JSON 字符串
            inner_json_string = outer_obj['data']['P0']

            # 4. 解析这个内部的 JSON 字符串 (e.g., "[{\"名称\": ...}, ...]")
            # 这才是我们真正想要保存的工件列表
            data_to_save = json.loads(inner_json_string)

            # --- ✅ 新增：将四元数从 [X, Y, Z, W] 转换为 [W, X, Y, Z] 格式 ---
            for item in data_to_save:
                # 检查是否存在 "Rotate" 键
                if "Rotate" in item:
                    # 从 Java/Scipy [X, Y, Z, W] 格式读取
                    quat_xyzw = item["Rotate"]
                    # 确保它是一个包含4个元素的列表
                    if isinstance(quat_xyzw, list) and len(quat_xyzw) == 4:
                        # 重新排序为 [W, X, Y, Z] 格式
                        # [w] = quat_xyzw[3]
                        # [x] = quat_xyzw[0]
                        # [y] = quat_xyzw[1]
                        # [z] = quat_xyzw[2]
                        item["Rotate"] = [quat_xyzw[3], quat_xyzw[0], quat_xyzw[1], quat_xyzw[2]]
            # -----------------------------------------------------------

            # 5. 将提取出的、格式转换后的工件列表写入 JSON 文件
            # 'w' 模式会覆盖已有文件，确保文件始终包含最新数据
            # encoding='utf-8' 确保中文字符能被正确写入
            # indent=4 使得 JSON 文件格式化，易于阅读
            # ensure_ascii=False 确保中文字符按原样写入，而不是被转义
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data_to_save, f, ensure_ascii=False, indent=4)

            print(f"数据已成功提取并保存到 {filename} (格式: [W, X, Y, Z])")

        else:
            # 如果服务器返回的 JSON 结构不是我们预期的
            print("错误：服务器响应的 JSON 中未找到 'data' 或 'P0' 键。")
            print(f"原始数据: {data_string}")

    except json.JSONDecodeError as e:
        # 如果任一阶段的 JSON 解析失败 (外层或内层)
        print(f"错误：解析 JSON 时出错。{e}")
        print(f"原始数据: {data_string}")
    except Exception as e:
        # 捕获其他可能的错误，例如文件写入权限问题
        print(f"保存到 {filename} 时发生错误: {e}")


# --- 修改：添加 socket_file 参数 ---
def communication_loop(client_socket, socket_file):
    """
    处理与服务器的持续通信。
    等待用户输入指令来决定何时发送数据。
    :param client_socket: 原始的 socket 对象 (保留，以备后用)
    :param socket_file: 包装后的文件对象，用于按行读写
    """
    while True:
        # 等待用户输入指令
        command = input(">>> 输入 'get' 来请求数据, 或输入 'exit' 退出: ")

        if command.lower() == 'get':
            try:
                # 准备要发送的 JSON 字符串 (与您提供的代码保持一致)
                # 修复：移除了 "P0" 后面的多余逗号
                message_to_send = '{"type":1,"data":{"S0":"P0"}}\n'

                print(f"发送消息: {message_to_send.strip()}")

                # --- 修改：使用 file 对象发送 ---
                # 将字符串编码为字节并发送
                socket_file.write(message_to_send.encode('utf-8'))
                # 确保数据立即发送，而不是在缓冲区等待
                socket_file.flush()

                # --- 修改：使用 file 对象接收 ---
                # 接收从服务器返回的数据
                print("等待服务器响应...")
                # .readline() 会读取数据，直到遇到换行符 \n
                data = socket_file.readline()

                if not data:
                    # 如果接收到的数据为空，表示服务器已主动关闭连接
                    print("与服务器的连接已断开。")
                    break  # 退出循环
                else:
                    # --- 修改：解码并移除末尾换行符 ---
                    # 将接收到的字节解码为字符串, 并 .strip() 移除末尾的 \n
                    decoded_data = data.decode('utf-8').strip()

                    if not decoded_data:  # 如果只收到了一个空行
                        print("收到了空响应。")
                        continue

                    print(f"收到服务器响应 (原始): {decoded_data}")

                    # --- 功能更新 ---
                    # 将收到的数据解析、提取并保存到 JSON 文件
                    save_data_to_json(decoded_data)
                    # --------------

            except Exception as e:
                print(f"与服务器通信时发生错误: {e}")
                break  # 发生错误时也退出循环

        elif command.lower() == 'exit':
            # 如果用户输入 'exit', 退出循环
            print("正在关闭连接...")
            break
        else:
            # 如果用户输入了无效指令
            print("无效的指令。请输入 'get' 或 'exit'。")


def start_client(host='127.0.0.1', port=2222):
    """
    启动一个 socket 客户端。如果服务器未开启，它会持续尝试连接。
    连接成功后，进入一个循环，等待用户指令来收发数据。
    """
    # 创建一个 socket 对象
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:

        # 持续尝试连接服务器
        while True:
            try:
                print(f"正在尝试连接到服务器 {host}:{port}...")
                client_socket.connect((host, port))
                print("已成功连接到服务器。")

                # --- 新增：包装 socket ---
                # 将 socket 包装成文件对象，以便按行读写 ('rwb' = 读写二进制)
                socket_file = client_socket.makefile('rwb')

                # --- 修改：传入 socket_file ---
                # 连接成功后，进入通信循环
                communication_loop(client_socket, socket_file)

                # --- 新增：关闭文件对象 ---
                # 循环结束后，关闭文件对象
                socket_file.close()

                # 从通信循环退出后，意味着程序即将结束
                break  # 跳出外层的连接循环

            except ConnectionRefusedError:
                print("连接失败。服务器可能未开启。将在 5 秒后重试...")
                time.sleep(5)
                # 这里不需要 break，会继续下一次循环尝试连接
            except Exception as e:
                print(f"发生未知错误: {e}")
                break  # 发生其他错误时退出

    print("客户端程序已关闭。")


if __name__ == '__main__':
    # 您可以根据需要更改 host 和 port
    start_client()