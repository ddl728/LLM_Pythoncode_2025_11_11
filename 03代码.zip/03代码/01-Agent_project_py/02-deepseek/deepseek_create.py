# Please install OpenAI SDK first: `pip3 install openai`
import time
import pandas as pd
from openai import OpenAI


def print_res(results, delay=0.1):
    for res in results:
        print(res, end="", flush=True)
        time.sleep(delay)
    print() # 最后一个打印，用于换行


def deepseek_gc2(prompt2):
    print("正在验证身份，请稍等...")
    # 访问接口进行，创建客户端对象
    client = OpenAI(api_key="sk-669120e8ba7541dfaeac9a2d405acb67", base_url="https://api.deepseek.com")
    print("正在思考，请耐心等候")
    # 发生请求,等待响应数据
    response = client.chat.completions.create(
        model="02-deepseek-chat", # 选择模型V3
        # model="02-deepseek-reasoner", # 选择模型R1

        messages=[
            {"role": "system", "content": "你是一个专业的客服助手，请用正式的语气回答用户的问题"},
            {"role": "user", "content": prompt2},
        ],
        stream=False
    )
    return response.choices[0].message.content

while True:
    # prompt = pd.read_csv("english_indx - 副本.csv",header=None)
    prompt = input("给Deepseek发送消息：")
    if prompt == "exit":
        print("欢迎下次使用，再见！")
        break
    result = deepseek_gc2(prompt)
    print_res(result)
    # print(deepseek_gc2(prompt))
    print("--------------------------")
