import os
import requests
from dotenv import load_dotenv
import asyncio

# -------------------------------
# 1. 加载环境变量
# -------------------------------
env_path = os.path.join(os.path.dirname(__file__), ".env")
load_dotenv(env_path)

DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")
MODEL = os.getenv("MODEL", "02-deepseek-chat")

if not DEEPSEEK_API_KEY:
    raise EnvironmentError("❌ 未检测到 DEEPSEEK_API_KEY，请在 .env 文件中配置。")

print("✅ MODEL =", MODEL)
print("✅ DEEPSEEK_API_KEY =", "已检测到" if DEEPSEEK_API_KEY else "未设置")


# -------------------------------
# 2. 定义 Agent 工具函数
# -------------------------------
def sum_nums(a: float, b: float) -> float:
    """简单计算工具函数"""
    return a + b


# -------------------------------
# 3. 定义 DeepSeek 请求函数
# -------------------------------
def deepseek_request(messages):
    """
    messages: [{"role": "user", "content": "..."}]
    """
    url = "https://api.deepseek.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": MODEL,
        "messages": messages
    }

    response = requests.post(url, headers=headers, json=payload)
    if response.status_code != 200:
        raise Exception(f"DeepSeek API 出错: {response.status_code} {response.text}")

    data = response.json()
    # DeepSeek 返回结果结构可能包含 choices[0].message.content
    return data["choices"][0]["message"]["content"]


# -------------------------------
# 4. 异步主函数
# -------------------------------
async def main():
    print("\n🤖 AI Assistant - Type 'exit' to quit\n")
    conversation_history = []

    while True:
        user_input = input("You: ").strip()
        if user_input.lower() in ["exit", "quit"]:
            print("👋 Goodbye")
            break
        if not user_input:
            continue

        # 将用户消息加入对话历史
        conversation_history.append({"role": "user", "content": user_input})

        try:
            # 调用 DeepSeek API
            assistant_reply = deepseek_request(conversation_history)

            # 将助手回复加入对话历史
            conversation_history.append({"role": "assistant", "content": assistant_reply})

            print(f"Assistant: {assistant_reply}\n")

        except Exception as e:
            print(f"⚠️ 出错：{e}")
            print("请检查网络或 DEEPSEEK_API_KEY 是否有效。\n")


# -------------------------------
# 5. 程序入口
# -------------------------------
if __name__ == "__main__":
    asyncio.run(main())
