from swarm.repl import run_demo_loop
from sql_agents import sql_router_agent

if __name__ == "__main__":
    run_demo_loop(sql_router_agent)