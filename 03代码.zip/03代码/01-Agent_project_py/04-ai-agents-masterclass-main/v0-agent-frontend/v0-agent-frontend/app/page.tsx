import AiAgentChatbot from "@/components/ai-agent-chatbot"

export default function Page() {
  return <AiAgentChatbot />
}