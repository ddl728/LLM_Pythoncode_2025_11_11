#!/bin/bash
wget http://virtual-home.org/release/programs/programs_processed_precond_nograb_morepreconds.zip
mv programs_processed_precond_nograb_morepreconds.zip dataset
cd dataset
unzip programs_processed_precond_nograb_morepreconds
cd ..
