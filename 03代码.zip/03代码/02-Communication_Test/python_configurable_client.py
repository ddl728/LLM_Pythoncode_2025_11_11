import socket
import time

"""
功能：测试用---处理与服务器的持续通信等待用户输入指令来决定何时发送数据。
"""
def communication_loop(client_socket):

    while True:
        # 等待用户输入指令
        command = input(">>> 输入 'get' 来请求数据, 或输入 'exit' 退出: ")

        if command.lower() == 'get':
            try:
                # 准备要发送的 JSON 字符串 (与您提供的代码保持一致)
                message_to_send = '{"type":1,"data":{"x_position":"X","y_position":"Y","z_position":"Z"}}\n'

                print(f"发送消息: {message_to_send.strip()}")
                # 将字符串编码为字节并发送
                client_socket.sendall(message_to_send.encode('utf-8'))

                # 接收从服务器返回的数据
                print("等待服务器响应...")
                data = client_socket.recv(1024)

                if not data:
                    # 如果接收到的数据为空，表示服务器已主动关闭连接
                    print("与服务器的连接已断开。")
                    break  # 退出循环
                else:
                    # 将接收到的字节解码为字符串并打印
                    print(f"收到服务器响应: {data.decode('utf-8')}")

            except Exception as e:
                print(f"与服务器通信时发生错误: {e}")
                break  # 发生错误时也退出循环

        elif command.lower() == 'exit':
            # 如果用户输入 'exit', 退出循环
            print("正在关闭连接...")
            break
        else:
            # 如果用户输入了无效指令
            print("无效的指令。请输入 'get' 或 'exit'。")


def start_client(host='127.0.0.1', port=2222):
    """
    启动一个 socket 客户端。如果服务器未开启，它会持续尝试连接。
    连接成功后，进入一个循环，等待用户指令来收发数据。
    """
    # 创建一个 socket 对象
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:

        # 持续尝试连接服务器
        while True:
            try:
                print(f"正在尝试连接到服务器 {host}:{port}...")
                client_socket.connect((host, port))
                print("已成功连接到服务器。")

                # 连接成功后，进入通信循环
                communication_loop(client_socket)

                # 从通信循环退出后，意味着程序即将结束
                break  # 跳出外层的连接循环

            except ConnectionRefusedError:
                print("连接失败。服务器可能未开启。将在 5 秒后重试...")
                time.sleep(5)
                # 这里不需要 break，会继续下一次循环尝试连接
            except Exception as e:
                print(f"发生未知错误: {e}")
                break  # 发生其他错误时退出

    print("客户端程序已关闭。")


if __name__ == '__main__':
    # 您可以根据需要更改 host 和 port
    start_client()