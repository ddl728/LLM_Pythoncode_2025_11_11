# robot_skill_library.py
import json
import numpy as np
import math
from scipy.spatial.transform import Rotation
from ikpy.chain import Chain
from ikpy.link import DHLink

"""
模块功能: 智能体的“技能库”与“验证器” (迭代指标)
1. 被 'skill_mapper.py' 调用。
2. 包含机器人的运动学模型 (DH 参数)。
3. 包含用于验证规划的函数 (IK 检查, 碰撞检查) - 【迭代指标】。
4. 包含实际执行机器人动作的函数 (MoveL, MoveJ) - 【技能】。
"""


# --- 运动学与 IK (从 calculate_relative_pose.py 移植) ---

def create_irb120_chain():
    """
    (内部函数) 使用 ABB IRB 120 的标准 DH (Denavit-Hartenberg) 参数
    创建一个 ikpy 运动学链 (机器人模型)。

    被调用:
    - 本模块加载时 (创建 ROBOT_CHAIN)
    """
    pi = math.pi
    # d (米): 连杆偏移
    d = [0.290, 0, 0, 0.302, 0, 0.072]
    # a (米): 连杆长度
    a = [0, 0.270, 0.070, 0, 0, 0]
    # alpha (弧度): 连杆扭转
    alpha = [-pi / 2, 0, -pi / 2, pi / 2, -pi / 2, 0]
    # theta (弧度): 关节偏移
    theta_offsets = [0, 0, pi / 6, 0, pi / 6, 0]

    # (此处省略了 bounds 定义, 您可以从 calculate_relative_pose.py 复制)
    # j1_bounds = (math.radians(-165), math.radians(165))

    chain = Chain(name='IRB120', links=[
        # 虚拟的 Base 连杆 (固定的)
        DHLink(d=0, a=0, alpha=0, theta=0, bounds=(0, 0), name='Base'),
        # 真实的 J1-J6 连杆 (带有关节限制)
        DHLink(d=d[0], a=a[0], alpha=alpha[0], theta=theta_offsets[0], name='J1'),  # bounds=j1_bounds
        DHLink(d=d[1], a=a[1], alpha=alpha[1], theta=theta_offsets[1], name='J2'),  # bounds=j2_bounds
        DHLink(d=d[2], a=a[2], alpha=alpha[2], theta=theta_offsets[2], name='J3'),  # bounds=j3_bounds
        DHLink(d=d[3], a=a[3], alpha=alpha[3], theta=theta_offsets[3], name='J4'),  # bounds=j4_bounds
        DHLink(d=d[4], a=a[4], alpha=alpha[4], theta=theta_offsets[4], name='J5'),  # bounds=j5_bounds
        DHLink(d=d[5], a=a[5], alpha=alpha[5], theta=theta_offsets[5], name='J6'),  # bounds=j6_bounds
        # 虚拟的 TCP 连杆 (固定的)
        DHLink(d=0, a=0, alpha=0, theta=0, bounds=(0, 0), name='TCP')
    ])
    return chain


def create_4x4_matrix(position, quaternion_xyzw):
    """
    (内部函数) 根据 [X,Y,Z] 和 [X,Y,Z,W] 格式的四元数
    创建一个 4x4 齐次变换矩阵。

    被调用:
    - (目前未被 execute_move 使用, 但保留)
    """
    try:
        rot_matrix_3x3 = Rotation.from_quat(quaternion_xyzw).as_matrix()
        matrix_4x4 = np.identity(4)
        matrix_4x4[0:3, 0:3] = rot_matrix_3x3
        matrix_4x4[0:3, 3] = position
        return matrix_4x4
    except Exception:
        return None


# 加载一次机器人模型 (全局变量), 避免重复创建
ROBOT_CHAIN = create_irb120_chain()


# --- 迭代指标 (验证函数) ---

def check_ik_reachability(target_position, target_orientation_matrix):
    """
    【迭代指标 1: 逆运动学可达性】
    检查一个目标位姿是否在机器人的工作空间内且可解。

    被调用:
    - `execute_move` (在本模块中)

    返回:
    (tuple): (True, joint_angles) 或 (False, error_message)
    """
    try:
        # 调用 ikpy 的核心功能：求解逆运动学
        target_joints_rad = ROBOT_CHAIN.inverse_kinematics(
            target_position=target_position,
            target_orientation=target_orientation_matrix,
            orientation_mode='all'
        )

        # 将角度转换为度数并标准化 ([-180, 180])
        target_joints_deg_raw = np.degrees(target_joints_rad[1:7])
        normalized_joints_deg = (target_joints_deg_raw + 180) % 360 - 180

        # 验证成功, 返回解
        return True, normalized_joints_deg

    except Exception as e:
        # 验证失败 (例如, 目标点太远, 机器人够不到)
        error_msg = f"IK 求解失败: {e} (目标可能在机器人工作范围之外)"
        # 返回失败状态和错误信息
        return False, error_msg


def check_collision(scene_data, start_joints, end_joints):
    """
    【迭代指标 2: 与障碍物体干涉反馈】(占位符)
    检查从一个姿态 (start_joints) 移动到另一个姿态 (end_joints)
    是否会与 'scene_data' 中的障碍物碰撞。

    被调用:
    - (未来将被 `execute_move` 调用)

    返回:
    (tuple): (True, None) 或 (False, "与'障碍物X'发生碰撞")
    """
    print(f"  [验证] 正在检查从 {start_joints} 到 {end_joints} 的路径碰撞...")

    # --- (未来实现) ---
    # 这是您需要与仿真平台 API (如 Visual Components, Isaac Sim)
    # 或专用的碰撞检测库 (如 FCL) 集成的地方。
    #
    # 1. 使用 ROBOT_CHAIN.forward_kinematics(start_joints) 获取机器人所有连杆的网格。
    # 2. 对 'scene_data' 中所有 'Type' != '机器人' 的对象创建碰撞网格。
    # 3. 在 'start_joints' 和 'end_joints' 之间进行插值。
    # 4. 检查每一步的机器人网格是否与场景网格碰撞。

    # 占位符：我们假设总是安全的
    is_safe = True
    if not is_safe:
        return False, "与'桌子'发生碰撞"

    return True, None


# --- 机器人技能 (行动函数) ---

def execute_move(target_pose_str, scene_data):
    """
    【技能】这是一个高层技能，它执行 LLM 的一个 'Move' 规划。
    它会运行所有“迭代指标”(验证)。

    被调用:
    - `skill_mapper.py` (在 `execute_task_plan` 中)

    返回:
    (dict): {"status": "success", ...} 或 {"status": "fail", "reason": "..."}
    """

    # 1. 解析 LLM 生成的字符串
    try:
        # LLM 返回 [X, Y, Z, QW, QX, QY, QZ]
        pose_list = json.loads(target_pose_str)
        position = pose_list[0:3]
        quaternion_wxyz = pose_list[3:7]  # [W, X, Y, Z]
    except Exception as e:
        return {"status": "fail", "reason": f"无法解析目标位姿: {e}"}

    # (我们假设 'position' 和 'quaternion_wxyz' 已经是相对于基座的,
    #  因为 'task_planner.py' 已经完成了预处理)

    # --- ✅ 核心: 适配 Scipy ---
    # 将 LLM 给的 [W, X, Y, Z] 转换为 Scipy 期望的 [X, Y, Z, W]
    try:
        quaternion_xyzw = [quaternion_wxyz[1], quaternion_wxyz[2], quaternion_wxyz[3], quaternion_wxyz[0]]
        orientation_matrix = Rotation.from_quat(quaternion_xyzw).as_matrix()
    except Exception as e:
        return {"status": "fail", "reason": f"无效的四元数格式: {e}"}

    # 3. 运行【迭代指标 1: IK 可达性】
    # 调用本模块中的 check_ik_reachability 函数
    is_reachable, ik_result = check_ik_reachability(position, orientation_matrix)

    if not is_reachable:
        # 如果 IK 验证失败, 立即返回失败反馈
        return {"status": "fail", "reason": ik_result}

    # 如果 IK 验证成功
    print(f"  [验证] IK 可达: {np.round(ik_result, 4)}")

    # 4. 运行【迭代指标 2: 碰撞检测】
    # (您需要获取当前关节角度 'current_joints' 才能进行检查)
    # current_joints = ... (从机器人 API 读取)
    # end_joints = ik_result
    # is_safe, collision_msg = check_collision(scene_data, current_joints, end_joints)

    # if not is_safe:
    #     return {"status": "fail", "reason": collision_msg}

    # 5. (如果所有验证通过) 实际执行 (占位符)
    print(f"  [执行] 正在移动到 {np.round(ik_result, 4)}...")
    # (此处调用您仿真平台的 API 来执行运动)
    # robot_api.move_joints(ik_result)

    return {"status": "success", "executed_joints": ik_result}


def execute_gripper(action):
    """
    【技能】执行夹爪动作

    被调用:
    - `skill_mapper.py` (在 `execute_task_plan` 中)
    """
    print(f"  [执行] 夹爪: {action}")
    # (此处调用您仿真平台的 API 来控制夹爪)
    # robot_api.set_gripper(action)
    return {"status": "success"}