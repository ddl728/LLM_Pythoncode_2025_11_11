# skill_mapper.py
import robot_skill_library  # <-- 导入“技能库”模块
import json

"""
模块功能: 智能体的“手臂” (执行调度器)
1. 接收来自 'main_controller.py' 的 JSON 规划。
2. 遍历 JSON 中的“操作步骤”。
3. 将规划中的动作 (例如 "MoveL_Grasp") 映射到 
   'robot_skill_library.py' 中真实的 Python 函数 (例如 execute_move)。
4. 检查技能库返回的验证结果 (IK, 碰撞等)。
5. 向 'main_controller.py' 报告成功或失败。
"""


# --- 修改：移除 async ---
def execute_task_plan(action_sequence, scene_data):
    """
    遍历动作序列，调用技能库，并执行验证 (迭代指标)。
    (已改为同步)

    被调用:
    - `main_controller.py` (在 `run_agent` 中)

    参数:
    action_sequence (dict): 从 'task_planner' 接收到的 JSON 规划。
    scene_data (list): 完整的场景数据 (用于碰撞检测)。

    返回:
    (tuple): (True, "成功") 或 (False, "失败原因")
    """

    if not action_sequence or "操作步骤" not in action_sequence:
        print("技能映射器: 无效的动作序列。")
        return False, "无效的动作序列"

    print("技能映射器: 正在执行规划好的动作步骤...")

    # 遍历 LLM 生成的每一个步骤
    for i, step in enumerate(action_sequence["操作步骤"]):
        action = step.get("动作")
        description = step.get("目标描述")

        print(f"\n--- 步骤 {i + 1}: 动作='{action}', 描述='{description}' ---")

        result = None

        # --- 核心：动作映射 ---
        # 将 LLM 的规划动作 (字符串) 映射到 Python 函数调用

        # 处理所有“移动”类动作
        if action in ["MoveJ_Safe", "MoveL_Grasp", "MoveL_Retract", "MoveJ_Home", "MoveL_Release"]:
            # (注意: MoveJ_Safe 和 Home 暂时也使用 MoveL 逻辑处理)

            # 从 JSON 中获取“目标位姿”字符串
            target_pose_str = step.get("目标位姿") or step.get("目标位置")
            if not target_pose_str:
                # 如果 LLM 忘记提供位姿 (例如 Home), 给一个默认安全位姿
                target_pose_str = "[0,0,0.5, 1,0,0,0]"  # 假设 Home [X,Y,Z, W,X,Y,Z]

            # 调用“技能库”中的 execute_move 函数
            # !! 验证(迭代指标)就在这个函数内部执行 !!
            result = robot_skill_library.execute_move(target_pose_str, scene_data)

        # 处理“夹爪”类动作
        elif action == "CloseGripper":
            result = robot_skill_library.execute_gripper("close")

        elif action == "OpenGripper":
            result = robot_skill_library.execute_gripper("open")

        else:
            print(f"  [警告] 未知的动作: {action}, 已跳过。")
            result = {"status": "success"}  # 暂时跳过

        # --- 检查“迭代指标”的反馈 ---
        # 检查 'execute_move' 或其他技能是否返回了失败
        if result and result.get("status") == "fail":
            failure_reason = result.get("reason", "未知错误")
            print(f"  [失败] 步骤 {i + 1} 执行失败: {failure_reason}")
            # 向 'main_controller' 报告失败, 并停止执行后续步骤
            return False, failure_reason

    print("\n技能映射器: 所有步骤执行成功。")
    return True, "任务成功"