# main_controller.py
import json
import re  # 导入正则表达式库, 用于从用户输入中提取目标
import knowledge_loader  # 导入“知识”模块
import task_planner  # 导入“规划”模块
import skill_mapper  # 导入“技能”模块
"""
主要功能：
1. 协调所有其他模块knowledge_loader, task_planner, skill_mapper
2. 接收用户的自然语言任务
3. 迭代优化输出结果
"""

# --- 配置 ---
# 从 'knowledge_loader' 模块导入已计算好的、健壮的 JSON 文件路径
# 这是整个智能体系统的核心知识来源
SCENE_DATA_FILE = knowledge_loader.DEFAULT_JSON_PATH


# --- 修改：移除 async ---
def run_agent(user_natural_language_task):
    """
    运行智能体的主函数 (同步版本)

    调用顺序:
    1. -> knowledge_loader.load_scene_data (加载知识)
    2. -> knowledge_loader.get_object_by_name (验证目标)
    3. -> task_planner.generate_action_sequence (生成规划)
    4. -> skill_mapper.execute_task_plan (执行与验证)

    参数:
    user_natural_language_task (str): 用户的自然语言指令, 例如 "抓取工件1..."
    """
    print(f"--- 任务开始: '{user_natural_language_task}' ---")

    # --- 1. 加载知识 (感知) ---
    print(f"正在加载场景数据: {SCENE_DATA_FILE}...")
    # 调用 'knowledge_loader' 模块中的函数来加载和解析 JSON 文件
    scene_data = knowledge_loader.load_scene_data(SCENE_DATA_FILE)
    if not scene_data:
        print("错误: 无法加载场景数据，任务终止。")
        return

    # --- 2. 验证任务 (动态解析) ---
    # (此功能已补全)
    target_object_name = None
    # 尝试使用正则表达式从 "抓取工件1..." 中动态提取 "工件1"
    match = re.search(r"抓取(.*?)(,|，|\s|然后|$)", user_natural_language_task)

    if match:
        target_object_name = match.group(1).strip()
        print(f"识别到目标: '{target_object_name}'")

        # 验证提取出的目标是否存在于场景中
        # 调用 'knowledge_loader' 模块中的函数
        target_object = knowledge_loader.get_object_by_name(scene_data, target_object_name)
        if not target_object:
            print(f"错误: 在场景数据中未找到 '{target_object_name}'，任务终止。")
            return
    else:
        print("警告: 未在指令中识别到明确的抓取目标。")
        # 即使如此, 我们仍然可以将整个任务交给 LLM 处理
        # (LLM 可能会从上下文中推断)
    # --- 验证结束 ---

    # --- 3. 规划与执行 (单次) ---

    # --- (迭代循环功能已被注释掉) ---
    # 这是未来实现迭代指标(IK、碰撞)反馈循环的地方
    # max_retries = 3
    # current_attempt = 1
    # task_feedback = None

    # while current_attempt <= max_retries:
    # --- (迭代循环功能已被注释掉) ---

    print(f"\n--- 规划阶段 ---")

    # (A) 调用 LLM 生成规划
    print("正在调用任务规划器 (LLM)...")

    # 调用 'task_planner' 模块中的函数
    # 它会(1)预处理坐标 (2)调用LLM (3)返回JSON
    action_sequence_json = task_planner.generate_action_sequence(
        user_natural_language_task,
        scene_data
        # task_feedback # (迭代功能已注释)
    )

    # 检查 LLM 是否成功返回了有效的 JSON
    if not action_sequence_json or "操作步骤" not in action_sequence_json:
        print("错误: LLM 未能生成有效的动作序列。")
        print("--- 任务失败 ---")
        return  # 退出

    print("--- LLM 规划结果 (JSON) ---")
    print(json.dumps(action_sequence_json, indent=2, ensure_ascii=False))

    # (B) 执行 (映射与验证)
    print("\n--- 技能映射与验证 ---")

    # 调用 'skill_mapper' 模块中的函数
    # 它会(1)解析JSON (2)调用'robot_skill_library'中的验证指标(IK)
    is_success, feedback_or_success_msg = skill_mapper.execute_task_plan(
        action_sequence_json,
        scene_data
    )

    # (C) 检查结果
    if is_success:
        print("\n--- 任务成功 ---")
        # return (迭代功能已注释)
    else:
        # 失败
        print(f"--- 任务失败: {feedback_or_success_msg} ---")
        # (迭代功能已注释)
        # task_feedback = feedback_or_success_msg
        # current_attempt += 1
        # (迭代功能已注释)

    # (迭代循环 'while' 结束)
    # print(f"--- 任务失败：已达最大重试次数 ({max_retries}) ---") (迭代功能已注释)


# --- 运行示例 ---
if __name__ == "__main__":
    """
    当这个脚本被直接运行时 (例如: python main_controller.py),
    此部分代码将被执行。
    """
    task = "抓取工件1，然后释放到目标位置(0,0,0)"

    # 运行智能体的主函数
    run_agent(task)