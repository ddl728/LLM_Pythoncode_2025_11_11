# task_planner.py
import json
import numpy as np  # 用于数学计算
import copy  # 用于深度复制数据, 避免修改原始数据
import os  # 用于获取环境变量
from scipy.spatial.transform import Rotation  # 用于四元数和矩阵运算

# --- ✅ 核心修改：借鉴 .md 附件，导入 OpenAI SDK ---
# 我们使用 OpenAI 的库来调用 DeepSeek, 因为它们共享相似的 API 格式
from openai import OpenAI

"""
模块功能: 智能体的“规划器” (LLM 核心)
1. 接收来自 'main_controller.py' 的任务和场景数据。
2. (预处理) 将 'scene_data' 中的世界坐标转换为相对坐标。
3. 构建 'system_prompt' 和 'user_prompt'。
4. 调用 DeepSeek API (使用 OpenAI SDK) 生成 JSON 动作序列。
5. 将 JSON 规划返回给 'main_controller.py'。
"""


# --- 坐标变换辅助函数 (内部调用) ---
def _create_4x4_matrix_from_wxyz(position, quat_wxyz):
    """
    (内部函数) 根据 [X,Y,Z] 和 [W,X,Y,Z] 格式的四元数
    创建一个 4x4 齐次变换矩阵。
    """
    try:
        # 1. 将 [W, X, Y, Z] 转换为 Scipy 期望的 [X, Y, Z, W]
        quat_xyzw = [quat_wxyz[1], quat_wxyz[2], quat_wxyz[3], quat_wxyz[0]]

        # 2. 从 [X,Y,Z,W] 四元数创建 3x3 旋转矩阵
        rot_matrix_3x3 = Rotation.from_quat(quat_xyzw).as_matrix()

        # 3. 创建 4x4 单位矩阵
        matrix_4x4 = np.identity(4)
        # 4. 填充旋转部分
        matrix_4x4[0:3, 0:3] = rot_matrix_3x3
        # 5. 填充位置部分
        matrix_4x4[0:3, 3] = position
        return matrix_4x4
    except Exception as e:
        print(f"错误: _create_4x4_matrix_from_wxyz 失败: {e}")
        return None


def _convert_scene_to_relative(scene_data_world):
    """
    (内部函数) 预处理步骤。
    将包含世界坐标的 scene_data 转换为包含
    相对于“基座”的相对坐标的 scene_data。

    输出的四元数格式将保持 [W, X, Y, Z]。

    被调用:
    - `generate_action_sequence` (在本模块中)
    """

    # 查找基座
    base_data = None
    for item in scene_data_world:
        if item.get("Type") == "机器人":
            base_data = item
            break

    if not base_data:
        print("错误: _convert_scene_to_relative 未找到机器人 '基座'")
        return scene_data_world  # 返回原数据

    # 1. 计算基座的逆矩阵 (T_base_to_world)
    base_pos_world = base_data["Location"]
    base_quat_world_wxyz = base_data["Rotate"]  # [W, X, Y, Z]
    T_world_to_base = _create_4x4_matrix_from_wxyz(base_pos_world, base_quat_world_wxyz)
    if T_world_to_base is None:
        return scene_data_world  # 转换失败

    # T_base_to_world = inv(T_world_to_base)
    T_base_to_world = np.linalg.inv(T_world_to_base)

    # 2. 遍历并转换所有工件
    # 我们使用 deepcopy 来确保原始的 scene_data (世界坐标) 不被修改
    relative_scene_data = copy.deepcopy(scene_data_world)

    for item in relative_scene_data:
        if item.get("Type") == "工件":
            wp_pos_world = item["Location"]
            wp_quat_world_wxyz = item["Rotate"]  # [W, X, Y, Z]

            T_world_to_workpiece = _create_4x4_matrix_from_wxyz(wp_pos_world, wp_quat_world_wxyz)
            if T_world_to_workpiece is None:
                continue  # 跳过此工件

            # 核心计算: T_base_to_workpiece = T_base_to_world @ T_world_to_workpiece
            T_base_to_workpiece = T_base_to_world @ T_world_to_workpiece

            # 提取相对位姿
            relative_pos = T_base_to_workpiece[0:3, 3]
            relative_rot_matrix = T_base_to_workpiece[0:3, 0:3]

            # --- ✅ 转换回 [W, X, Y, Z] 格式 ---
            relative_quat_xyzw = Rotation.from_matrix(relative_rot_matrix).as_quat()  # [X,Y,Z,W]
            # 重新排序为 [W, X, Y, Z]
            relative_quat_wxyz = [relative_quat_xyzw[3], relative_quat_xyzw[0], relative_quat_xyzw[1],
                                  relative_quat_xyzw[2]]

            # 更新 item 中的数据
            item["Location"] = relative_pos.tolist()
            item["Rotate"] = relative_quat_wxyz  # 保存为 [W, X, Y, Z]

    return relative_scene_data


# --- 坐标变换函数结束 ---


# --- ✅ 核心修改：改为调用 DeepSeek API (使用 OpenAI SDK) ---
def generate_action_sequence(user_task, scene_data, feedback=None):
    """
    调用 DeepSeek API 将自然语言任务和场景数据转换为动作序列。
    (已改为同步, 移除了 feedback 参数)

    被调用:
    - `main_controller.py` (在 `run_agent` 中)
    """

    # --- 1. 坐标变换 (预处理) ---
    print("正在将世界坐标转换为相对坐标...")
    # 调用本模块中的 _convert_scene_to_relative 函数
    relative_scene_data = _convert_scene_to_relative(scene_data)

    # --- 2. 定义 LLM 的角色 (系统提示) ---
    system_prompt = """
    你是一个专业的工业机器人任务规划智能体。
    你的任务是接收用户的自然语言指令和一份描述场景中所有对象(机器人、工件)的 JSON 数据。
    你必须将指令分解为一系列机器人动作，并以严格的 JSON 格式输出。

    重要: 你收到的 'scene_data' 中的所有 'Location' 和 'Rotate' 数据
    **已经是相对于机器人基座的相对坐标**。

    场景数据中的 'Location' 是 [X, Y, Z] 坐标。
    场景数据中的 'Rotate' 是 [W, X, Y, Z] 四元数。

    你的输出 JSON 必须符合以下 Python 字典结构:
    {
      "操作步骤": [
        {
          "机器人": "IRB 120",
          "动作": "MoveJ_Safe",
          "目标描述": "移动到抓取 '工件X' 前的安全预备点"
        },
        {
          "机器人": "IRB 120",
          "动作": "MoveL_Grasp",
          "目标位姿": "[X, Y, Z, QW, QX, QY, QZ]",
          "目标描述": "线性移动到 '工件X' 的抓取位姿"
        },
        {
          "机器人": "IRB 120",
          "动作": "CloseGripper",
          "目标描述": "闭合夹爪"
        },
        {
          "机器人": "IRB 120",
          "动作": "OpenGripper",
          "目标描述": "打开夹爪"
        },
        {
          "机器人": "IRB 120",
          "动作": "MoveJ_Home",
          "目标描述": "返回 Home 位置"
        }
      ]
    }

    重要规则:
    1.  你必须从 'scene_data' 中**直接使用**目标工件 (例如 '工件1') 的 'Location' 和 'Rotate' (它们已经是相对坐标) 来填充 '目标位姿'。
    2.  '目标位姿' 必须是一个**字符串**，包含7个值: [X, Y, Z, QW, QX, QY, QZ] (3个位置 + 4个四元数 [W, X, Y, Z])。
    3.  例如: "目标位姿": "[-0.173, 0.07, 0.264, 0.0, 0.0, 1.0, 0.0]"
    4.  如果用户指定了如 '(0,0,0)' 这样的 '目标位置'，这**也是相对坐标**，你必须使用它。
    5.  你必须为抓取和释放动作规划一个安全的“预备点”(Approach Point) 和“退回点”(Retract Point)。一个好的策略是在目标点的 Z 轴上增加 0.1 米 (100mm)。
    6.  你必须使用 "IRB 120" 作为机器人名称。
    """

    # --- 3. 构建用户提示 ---
    scene_context = json.dumps(relative_scene_data, ensure_ascii=False, indent=2)

    user_prompt_for_llm = f"""
    --- 用户任务 ---
    {user_task}

    --- 场景数据上下文 (坐标已相对基座, 四元数 [W, X, Y, Z]) ---
    {scene_context}
    """

    # (迭代功能已注释)
    # if feedback:
    #    user_prompt_for_llm += ...

    user_prompt_for_llm += "\n请根据以上任务和场景数据，生成 JSON 动作序列。"

    # --- 4. 调用 DeepSeek API (使用 OpenAI SDK, 借鉴 .md) ---
    try:
        # 从环境变量获取 API 密钥
        api_key = os.environ.get("DEEPSEEK_API_KEY")
        if not api_key:
            print("错误: 未设置 DEEPSEEK_API_KEY 环境变量。")
            return None

        # (借鉴 .md) 创建客户端对象
        # SDK 会自动处理系统代理 (这是它优于 requests 的地方)
        client = OpenAI(api_key=api_key, base_url="https://api.deepseek.com")

        # (借鉴 .md) 发生请求,等待响应数据
        response = client.chat.completions.create(
            model="deepseek-chat",  # 使用 deepseek 聊天模型
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt_for_llm}
            ],
            response_format={"type": "json_object"},  # 请求 JSON 输出
            stream=False  # 使用非流式, 一次性获取结果
        )

        # 5. 解析 DeepSeek 的响应 (借鉴 .md)
        if (response.choices and
                response.choices[0].message and
                response.choices[0].message.content):

            # 提取 LLM 回复的 JSON 字符串
            json_text = response.choices[0].message.content
            # 将 JSON 字符串解析为 Python 字典
            return json.loads(json_text)
        else:
            print("错误: DeepSeek API 返回了无效的响应结构。")
            print("完整响应:", response)
            return None

    except Exception as e:
        print(f"调用 DeepSeek API 时发生错误: {e}")
        # 捕获所有错误 (如 API 密钥无效, 网络问题, 404)
        return None