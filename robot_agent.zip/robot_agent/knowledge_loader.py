# knowledge_loader.py
import json
import os

"""
模块功能: 智能体的“眼睛” (感知)
负责加载、解析和查询 'scene_data.json'
"""

# --- ✅ 修复：构建一个健壮的、绝对的文件路径 ---
# 1. 获取当前文件 (knowledge_loader.py) 所在的目录
#    例如: /.../agent_project/robot_agent/
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# 2. 构建到 scene_data.json 的相对路径
#    从 SCRIPT_DIR (robot_agent) 向上一级 (..) 到 agent_project,
#    再向上一级 (..) 到 [项目根目录],
#    然后进入 'scene_analysis'
# 3. 使用 os.path.abspath() 将其转换为一个“干净”的绝对路径
DEFAULT_JSON_PATH = os.path.abspath(os.path.join(SCRIPT_DIR, '..', '..', 'scene_analysis', 'scene_data.json'))


# --- 路径修复结束 ---


def load_scene_data(filename=DEFAULT_JSON_PATH):
    """
    从 JSON 文件加载完整的场景数据。

    被调用:
    - `main_controller.py` (在 `run_agent` 中)
    - `calculate_relative_pose.py` (在 `load_data` 中, 尽管那个文件有自己的加载器, 但逻辑相同)

    参数:
    filename (str): JSON 文件的路径。默认为计算好的 DEFAULT_JSON_PATH。

    返回:
    (list): 解析后的 JSON 数据 (一个对象列表), 或 None (如果失败)。
    """

    # 检查文件是否存在
    if not os.path.exists(filename):
        print(f"错误: 知识文件未找到: {filename}")
        return None

    try:
        # 打开并加载 JSON 文件
        with open(filename, 'r', encoding='utf-8') as f:
            data = json.load(f)

        # --- ✅ 修改：移除四元数转换 ---
        # (原 [W,X,Y,Z] -> [X,Y,Z,W] 的转换代码块已删除)
        # 此函数现在直接返回文件中的 [W, X, Y, Z] 格式,
        # 数据的预处理(坐标转换)将由 'task_planner.py' 负责。

        return data
    except json.JSONDecodeError:
        print(f"错误: {filename} 文件中的 JSON 格式不正确。")
        return None
    except Exception as e:
        print(f"加载 {filename} 时发生错误: {e}")
        return None


def get_object_by_name(scene_data, name):
    """
    根据名称从场景数据(列表)中查找一个对象(字典)。

    被调用:
    - `main_controller.py` (在 `run_agent` 中, 用于验证目标是否存在)

    参数:
    scene_data (list): 从 load_scene_data() 返回的数据。
    name (str): 要查找的对象的 "Name" 属性。

    返回:
    (dict): 找到的对象, 或 None (如果未找到)。
    """
    if not scene_data:
        return None

    for item in scene_data:
        if item.get("Name") == name:
            return item
    return None


def get_all_object_names(scene_data):
    """
    (辅助函数) 获取场景中所有对象的名称列表, 为 LLM 提供上下文。

    被调用:
    - (目前未被 `main_controller` 调用, 但未来可用于构建更丰富的提示)

    参数:
    scene_data (list): 从 load_scene_data() 返回的数据。

    返回:
    (list): 场景中所有对象的名称列表。
    """
    if not scene_data:
        return []

    names = [item.get("Name") for item in scene_data if item.get("Name")]
    return names