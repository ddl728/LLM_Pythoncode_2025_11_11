# client.py
import socket
import time
import json  # 导入 JSON 模块
import os  # 确保 os 已导入

"""
模块功能: (独立工具) 场景数据采集器
1. (手动运行) 连接到仿真软件 (运行 SignalScript.java) 的 Socket 服务器。
2. 发送 'get' 命令。
3. 接收场景数据字符串。
4. 将数据保存到当前目录下的 'scene_data.json'。
"""

# --- ✅ 修改：简化路径，保存到当前工作目录 ---
DEFAULT_SAVE_PATH = 'scene_data.json'
# ----------------------------------------


def save_data_to_json(data_string, filename=DEFAULT_SAVE_PATH):
    """
    将接收到的字符串数据解析为 JSON，提取内部的数据，
    并将其永久存储到文件中。

    被调用:
    - `communication_loop` (在本模块中)
    """
    try:
        # 1. 解析外层 JSON 字符串 (e.g., {"type": 1, "data": {...}})
        outer_obj = json.loads(data_string)

        # 2. 检查 "data" 和 "P0" 键是否存在
        if 'data' in outer_obj and 'P0' in outer_obj['data']:
            # 3. 提取 "P0" 键的值，它本身是一个 JSON 字符串
            #    (例如: "[{\"Name\": ...}]")
            inner_json_string = outer_obj['data']['P0']

            # 4. 解析这个内部的 JSON 字符串
            data_to_save = json.loads(inner_json_string)

            # --- ✅ 修改：移除四元数重排序 ---
            # 根据您的指示，原始数据已经是 [X, Y, Z, W] 格式，
            # 因此不需要再进行转换。直接保存即可。

            # 5. 将提取出的数据列表写入 JSON 文件
            # 'w' 模式会覆盖已有文件
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data_to_save, f, ensure_ascii=False, indent=4)

            print(f"数据已成功提取并保存到 {filename}")
            print(f"数据条目数: {len(data_to_save)}")

        else:
            # 如果服务器返回的 JSON 结构不是我们预期的
            print("错误：服务器响应的 JSON 中未找到 'data' 或 'P0' 键。")
            print(f"原始数据: {data_string}")

    except json.JSONDecodeError as e:
        # 如果任一阶段的 JSON 解析失败 (外层或内层)
        print(f"错误：解析 JSON 时出错。{e}")
        print(f"原始数据: {data_string}")
    except Exception as e:
        # 捕获其他可能的错误，例如文件写入权限问题
        print(f"保存到 {filename} 时发生错误: {e}")


def communication_loop(client_socket, socket_file):
    """
    (内部函数) 处理与服务器的持续通信。
    等待用户输入指令来决定何时发送数据。

    被调用:
    - `start_client` (在本模块中)
    """
    while True:
        # 等待用户输入指令
        command = input(">>> 输入 'get' 来请求数据, 或输入 'exit' 退出: ")

        if command.lower() == 'get':
            try:
                # 准备要发送的 JSON 字符串 (这是服务器的 API)
                message_to_send = '{"type":1,"data":{"S0":"P0"}}\n'

                print(f"发送消息: {message_to_send.strip()}")

                # --- 修改：使用 file 对象发送 ---
                # 将字符串编码为字节并发送
                socket_file.write(message_to_send.encode('utf-8'))
                # 确保数据立即发送，而不是在缓冲区等待
                socket_file.flush()

                # --- 修改：使用 file 对象接收 ---
                # 接收从服务器返回的数据
                print("等待服务器响应...")
                # .readline() 会读取数据，直到遇到换行符 \n
                # (这是为了防止 1024 字节截断)
                data = socket_file.readline()

                if not data:
                    # 如果接收到的数据为空，表示服务器已主动关闭连接
                    print("与服务器的连接已断开。")
                    break  # 退出循环
                else:
                    # --- 修改：解码并移除末尾换行符 ---
                    # 将接收到的字节解码为字符串, 并 .strip() 移除末尾的 \n
                    decoded_data = data.decode('utf-8').strip()

                    if not decoded_data:  # 如果只收到了一个空行
                        print("收到了空响应。")
                        continue

                    print(f"收到服务器响应 (原始): {decoded_data[:100]}... (省略过长内容)")

                    # --- 功能更新 ---
                    # 调用本模块中的 save_data_to_json
                    save_data_to_json(decoded_data)
                    # --------------

            except Exception as e:
                print(f"与服务器通信时发生错误: {e}")
                break  # 发生错误时也退出循环

        elif command.lower() == 'exit':
            # 如果用户输入 'exit', 退出循环
            print("正在关闭连接...")
            break
        else:
            # 如果用户输入了无效指令
            print("无效的指令。请输入 'get' 或 'exit'。")


def start_client(host='127.0.0.1', port=2222):
    """
    启动一个 socket 客户端。如果服务器未开启，它会持续尝试连接。
    连接成功后，进入一个循环，等待用户指令来收发数据。

    被调用:
    - (当 `if __name__ == '__main__':` 运行时)
    """
    # 创建一个 socket 对象
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:

        # 持续尝试连接服务器
        while True:
            try:
                print(f"正在尝试连接到服务器 {host}:{port}...")
                client_socket.connect((host, port))
                print("已成功连接到服务器。")

                # --- 新增：包装 socket ---
                # 将 socket 包装成文件对象，以便按行读写 ('rwb' = 读写二进制)
                # 这是为了使用 .readline()
                socket_file = client_socket.makefile('rwb')

                # --- 修改：传入 socket_file ---
                # 连接成功后，进入通信循环
                communication_loop(client_socket, socket_file)

                # --- 新增：关闭文件对象 ---
                # 循环结束后，关闭文件对象
                socket_file.close()

                # 从通信循环退出后，意味着程序即将结束
                break  # 跳出外层的连接循环

            except ConnectionRefusedError:
                print("连接失败。服务器可能未开启。将在 5 秒后重试...")
                time.sleep(5)
                # 这里不需要 break，会继续下一次循环尝试连接
            except Exception as e:
                print(f"发生未知错误: {e}")
                break  # 发生其他错误时退出

    print("客户端程序已关闭。")


if __name__ == '__main__':
    """
    当这个脚本被直接运行时 (例如: python client.py),
    此部分代码将被执行。
    """
    # 您可以根据需要更改 host 和 port
    start_client()