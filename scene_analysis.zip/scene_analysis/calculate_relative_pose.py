import json
import numpy as np
import math  # 导入 math 库用于 pi

"""
功能：[1] 将得到机器人基座位姿和工件的位姿，计算工件相对于机器人的相对位姿(坐标+四元数)，
         最后用于机器人脚本参数的输入。
     [2] 假定输入的 JSON (scene_data.json) 中的四元数格式为 [X, Y, Z, W]。
     [3] 最终输出的相对位姿四元数格式也为 [X, Y, Z, W]。
"""

# 尝试导入 scipy
try:
    from scipy.spatial.transform import Rotation
except ImportError:
    print("错误：未找到 scipy 库。")
    print("请先安装: pip install scipy numpy")
    exit()


def create_4x4_matrix(position, quat_xyzw):
    """
    根据位置 (list) 和四元数 (list [X, Y, Z, W])
    创建一个 4x4 齐次变换矩阵。
    """
    try:
        # --- 修正：直接使用 [X, Y, Z, W] ---
        # Scipy 的 from_quat 期望 [X, Y, Z, W] 格式
        # 既然输入已经是 [X, Y, Z, W]，不需要任何转换
        rot_matrix_3x3 = Rotation.from_quat(quat_xyzw).as_matrix()

    except Exception as e:
        print(f"错误：无效的四元数 [X,Y,Z,W] {quat_xyzw}。{e}")
        return None

    # 创建 4x4 齐次矩阵
    matrix_4x4 = np.identity(4)
    matrix_4x4[0:3, 0:3] = rot_matrix_3x3
    matrix_4x4[0:3, 3] = position

    return matrix_4x4


def load_data(filename='scene_data.json'):
    """
    从 JSON 文件加载场景数据。
    期望四元数数据格式为 [X, Y, Z, W]
    """
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data
    except FileNotFoundError:
        print(f"错误：未找到 {filename}。")
        print("请先运行 client.py 并输入 'get' 来生成该文件。")
        return None
    except json.JSONDecodeError:
        print(f"错误：{filename} 文件中的 JSON 格式不正确。")
        return None


def calculate_poses():
    """
    主函数：加载数据，执行坐标变换。
    """
    # 0. 加载数据
    scene_data = load_data()
    if not scene_data:
        return

    # 1. 查找并提取机器人基座的数据、Home点数据以及工件数据
    robot_base_data = None
    home_point_data = None
    workpieces_data = []

    for item in scene_data:
        if item.get("Type") == "机器人":
            robot_base_data = item
        elif item.get("Type") == "Home":
            home_point_data = item
        elif item.get("Type") == "工件":
            workpieces_data.append(item)

    if not robot_base_data:
        print("错误：在 scene_data.json 中未找到 'Type' 为 '机器人' 的基座数据。")
        return

    # 2. 创建机器人基座的 4x4 变换矩阵 (T_world_to_base)
    #    数据从 load_data 传来，是 [X, Y, Z, W] 格式
    base_pos = robot_base_data["Location"]
    base_quat_xyzw = robot_base_data["Rotate"]
    T_world_to_base = create_4x4_matrix(base_pos, base_quat_xyzw)

    if T_world_to_base is None:
        print("错误：机器人基座的四元数无效，计算中止。")
        return

    # 3. 计算从 "世界" 返回到 "基座" 的逆矩阵 (T_base_to_world)
    #    这是从基座坐标系看向世界坐标系的变换
    T_base_to_world = np.linalg.inv(T_world_to_base)

    print("-" * 40)
    print(f"机器人基座 '{robot_base_data.get('Name')}' 加载成功。")
    if home_point_data:
        print(f"Home点 '{home_point_data.get('Name')}' 加载成功。")
    print(f"找到 {len(workpieces_data)} 个工件。")
    print("开始计算相对于基座的坐标：\n")

    # --- 计算 Home 点相对于基座的位姿 ---
    if home_point_data:
        hp_name = home_point_data["Name"]
        hp_pos_world = home_point_data["Location"]
        hp_quat_world_xyzw = home_point_data["Rotate"]  # [X, Y, Z, W]

        T_world_to_home = create_4x4_matrix(hp_pos_world, hp_quat_world_xyzw)

        if T_world_to_home is not None:
            # 核心计算
            T_base_to_home = T_base_to_world @ T_world_to_home

            # 提取相对位姿
            final_pos_in_base = T_base_to_home[0:3, 3]
            final_rot_matrix = T_base_to_home[0:3, 0:3]
            final_rotation = Rotation.from_matrix(final_rot_matrix)
            final_euler_in_base_deg = final_rotation.as_euler('xyz', degrees=True)

            # Scipy 返回 [X, Y, Z, W]
            final_quat_xyzw_in_base = final_rotation.as_quat()

            # --- 格式化输出 ---
            pos_str = f"[{', '.join([f'{v:g}f' for v in final_pos_in_base])}]"
            euler_str = f"[{', '.join([f'{v:.0f}' for v in final_euler_in_base_deg])}]"

            # --- 修正：直接使用 Scipy 返回的 [X, Y, Z, W] ---
            quat_str = f"[{', '.join([f'{v:g}' for v in final_quat_xyzw_in_base])}]"

            print(f"--- {hp_name} (相对于基座) ---")
            print(f"  位置 (X, Y, Z): {pos_str}")
            print(f"  欧拉角 (绕X, Y, Z旋转/度): {euler_str}")
            print(f"  (四元数 X, Y, Z, W): {quat_str}")
            print("\n")

    # 4. 遍历所有工件，计算它们相对于基座的位姿
    for wp in workpieces_data:
        wp_name = wp["Name"]
        wp_pos_world = wp["Location"]
        wp_quat_world_xyzw = wp["Rotate"]  # [X, Y, Z, W] 格式

        # 5. 创建工件的 4x4 变换矩阵 (T_world_to_workpiece)
        T_world_to_workpiece = create_4x4_matrix(wp_pos_world, wp_quat_world_xyzw)

        if T_world_to_workpiece is None:
            print(f"跳过 {wp_name} (无效的四元数)")
            continue

        # 6. 【核心计算】
        #    T_base_to_workpiece = T_base_to_world * T_world_to_workpiece
        T_base_to_workpiece = T_base_to_world @ T_world_to_workpiece

        # 7. 从最终的 4x4 矩阵中提取出机器人需要的位置和姿态
        final_pos_in_base = T_base_to_workpiece[0:3, 3]
        final_rot_matrix = T_base_to_workpiece[0:3, 0:3]
        final_rotation = Rotation.from_matrix(final_rot_matrix)
        final_euler_in_base_deg = final_rotation.as_euler('xyz', degrees=True)

        # Scipy 的 as_quat() 返回 [X, Y, Z, W]
        final_quat_xyzw_in_base = final_rotation.as_quat()

        # --- 格式化输出字符串 ---

        # 格式化位置: [-0.1735f, 0.07f, ...]
        pos_str = f"[{', '.join([f'{v:g}f' for v in final_pos_in_base])}]"

        # 格式化欧拉角: [180, 0, 180]
        euler_str = f"[{', '.join([f'{v:.0f}' for v in final_euler_in_base_deg])}]"

        # 格式化四元数:
        # --- 修正：直接使用 Scipy 返回的 [X, Y, Z, W] ---
        quat_str = f"[{', '.join([f'{v:g}' for v in final_quat_xyzw_in_base])}]"

        # 打印结果
        print(f"--- {wp_name} (相对于基座) ---")
        print(f"  位置 (X, Y, Z): {pos_str}")
        print(f"  欧拉角 (绕X, Y, Z旋转/度): {euler_str}")
        print(f"  (四元数 X, Y, Z, W): {quat_str}")
        print("\n")


if __name__ == "__main__":
    calculate_poses()